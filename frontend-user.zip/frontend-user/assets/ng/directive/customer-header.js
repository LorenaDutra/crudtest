'use strict';

angular.module('customerApp').directive('portalCustomerHeader', function(AuthenticationService) {

	function link(scope, element, attrs) {
	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-header.html',
    	scope: { data: '=data' },
    	link: link
  	};

});