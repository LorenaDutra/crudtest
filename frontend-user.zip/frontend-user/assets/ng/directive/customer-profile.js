'use strict';

angular.module('customerApp').directive('portalCustomerProfile', function(AppService, $location, SERVER_CONFIG, AuthenticationService) {

	function link(scope, element, attrs) {
		scope.currentUser = SERVER_CONFIG.CURRENT_USER_DATA;
		//Gets the logged user
	  	AuthenticationService.getCurrentUser({}, function(currentUser) {
		    angular.copy(currentUser, SERVER_CONFIG.CURRENT_USER_DATA);
		}, function(error) {
		    $location.path('#/login');
		});
		scope.profile = function() {
	        AppService.openProfileEdition(function() {});
    	};
	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-profile.html',
    	scope: { data: '=data' },
    	link: link
  	};

});
