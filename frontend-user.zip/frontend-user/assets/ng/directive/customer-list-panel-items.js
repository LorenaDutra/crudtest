'use strict';

/******************* PARAMETROS **********************
{
 itemWrapper: function(domain) { return { title: domain.name, .... }; },
 actionButtons: ['edit', 'remove'],
 items: [
  {
    'id': 150,
    'title': 'donida',
    'descriptionFields': ['150', 'donida', 'admin@revolua.com', 'Ronaldo Donida', '******'],
	'extraButtons': function(item) { return [{className: 'fa fa-plus', action: function(item) { ... }}] },
	'disableEdit' : true,
	'disableRemove' : true,
    'editAction': function(id) { alert('Edit: ' + id); },
    'deleteAction': function(id, callback, error) {/* Use Callback Like in Filter Action // alert('Delete: ' + id); callback(id);}
  }
]
}
**********************************************************/
angular.module('customerApp').directive('customerListPanelItems', function(SERVER_CONFIG, AppService) {

	function link(scope, element, attrs) {
    var itemMap;

	scope.extraButtons = [];

    itemMap = function(item) {
      var formatted = scope.data.itemWrapper(item);
      formatted.editAction = item.editAction;
      formatted.deleteAction = item.removeAction;

      return formatted;
    };

	scope.data.extraButtons = scope.data.extraButtons || function(item) {
		return [];
	};

	scope.isEditionEnabled = function() {
		return scope.data.disableEdit !== true;
	};
	scope.isRemoveEnabled = function() {
		return scope.data.disableRemove !== true;
	};

    scope.formattedItems = scope.data.items.map(itemMap);
    scope.$watch('data.items', function() {

	  // Format items
	  scope.formattedItems = scope.data.items.map(itemMap);

	  // Add extra buttons
	  scope.extraButtons.splice(0, scope.extraButtons.length);
	  for (var i in scope.data.items) {
		var item = angular.copy(scope.data.items[i]);
		scope.extraButtons.push(scope.data.extraButtons(item));
	  }
    }, true);

    scope.edit = function(item) {
      item.editAction(item.id, function(loaded) {
        angular.copy(itemMap(loaded), item);
      }, function() {
        console.error('Error');
      });
    };

    scope.remove = function(item) {
      item.deleteAction(item.id, function() {
        scope.formattedItems.splice(
          scope.formattedItems.indexOf(item),
          1
        );
      }, function(message) {
        console.error('Error');
        if (message)
          AppService.errorMessage(message);
      });
    };
	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-list-panel-items.html',
    	scope: { data: '=data' },
    	link: link
  	};

});
