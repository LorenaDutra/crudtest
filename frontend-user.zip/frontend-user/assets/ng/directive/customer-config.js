'use strict';

angular.module('customerApp').directive('portalCustomerConfig', function() {

	function link(scope, element, attrs) {
	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-config.html',
    	scope: { data: '=data' },
    	link: link
  	};

});