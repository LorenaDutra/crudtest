'use strict';

angular.module('customerApp').directive('portalCustomerBreadcrumb', function(AppService, SERVER_CONFIG) {

	function link(scope, element, attrs) {
		AppService.resetCrumbs();
		if (scope.data) {
			angular.forEach(scope.data, function(crumb) {
				AppService.pushCrumb(crumb);
			});
		}
		scope.crumbs = SERVER_CONFIG.CRUMBS;
		scope.locales = SERVER_CONFIG.LOCALES;

		scope.updateLocale = function(locale) {
			AppService.setLocale(locale);
		};
	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-breadcrumb.html',
    	scope: { data: '=data' },
    	link: link
  	};

});
