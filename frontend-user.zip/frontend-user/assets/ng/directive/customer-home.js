'use strict';

angular.module('customerApp').directive('portalCustomerHome', function() {

	function link(scope, element, attrs) {

	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-home.html',
    	scope: { data: '=data' },
    	link: link
  	};

});