'use strict';

angular.module('customerApp').directive('portalCustomerLogin', function($location, AppService, AuthenticationService, SERVER_CONFIG) {

	function link(scope, element, attrs) {
		if (!scope.data) {
			scope.data = {};
		}
		scope.messages = SERVER_CONFIG.MESSAGES;
		scope.loginValidation = function(form) {
			var valid = true;
			if (!form.login || form.login == '') {
				// TODO i18n
				AppService.addErrorMessage('Login required...');
				valid = false;
			}
			if (!form.password || form.password == '') {
				// TODO i18n
				AppService.addErrorMessage('Password required...');
				valid = false;
			}
			return valid;
		};
		scope.login = function(event) {
			if (scope.loginValidation(scope.data)) {
				AuthenticationService.login(scope.data, function(response) {
					$location.path('/');
				});
			}
		};
	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-login.html',
    	scope: { data: '=data' },
    	link: link
  	};

});

