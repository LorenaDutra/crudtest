'use strict';

/******************* PARAMETROS **********************
{
	'title': 'Usuários',
	'newAction': function(event) { alert('New!!!'); },
	'printAction': function(type, filter, event) { alert('Printed: ' + type + ' Filter by: ' + filter); }, // type: PDF | XLS, filter: Current filter field value
	'filterAction': function(filter, callback, error) { //var mockData = []; // End Mock  callback(mockData); } // On Ajax Error call error...
	'list': {
		itemWrapper: function(domain) { return { title: domain.name, .... }; },
		'items': [
			{
				'id': 150,
				'title': 'donida',
				'descriptionFields': ['150', 'donida', 'admin@revolua.com', 'Ronaldo Donida', '******'],
				'editAction': function(id) { alert('Edit: ' + id); },
				'deleteAction': function(id, callback, error) { // Use Callback Like in Filter Action // alert('Delete: ' + id); callback(id);}
			}
		]
	}
}
***********************************************************/
angular.module('customerApp').directive('customerListPanel', function(SERVER_CONFIG) {

	function link(scope, element, attrs) {
		scope.search = {
			name: '',
			debounce: SERVER_CONFIG.TYPING_DEBOUNCE
		};

		// Print pdf or excel
		scope.print = function(type, event) {
			var filter = {
				search: scope.search
			};
			scope.data.printAction(type, filter, event);
		};

		scope.closeSearchPanel = function() {
			scope.isSearching = false;
			if (! scope.isSearching) {
				scope.search.name = '';
			}
		};

		// On search field typed
		scope.$watch('search.name', function() {
			var success,
			    error;

			success = function(list) {
				angular.copy(list, scope.data.list.items);
			};

			error = function() {
				console.error('Error on list');
			};

			//scope.data.filterAction(scope.search.name, success, error, event);
		});
	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-list-panel.html',
    	scope: { data: '=data' },
    	link: link
  	};

});
