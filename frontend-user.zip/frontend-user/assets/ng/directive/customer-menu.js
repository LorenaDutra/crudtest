'use strict';

angular.module('customerApp').directive('portalCustomerMenu', function(SERVER_CONFIG) {

	function link(scope, element, attrs) {
		scope.menus = SERVER_CONFIG.MENUS;
	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-menu.html',
    	scope: { data: '=data' },
    	link: link
  	};

});