'use strict';

angular.module('customerApp').directive('portalCustomerFooter', function() {

	function link(scope, element, attrs) {

	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-footer.html',
    	scope: { data: '=data' },
    	link: link
  	};

});