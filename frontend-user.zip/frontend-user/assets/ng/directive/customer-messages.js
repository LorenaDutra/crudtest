'use strict';

angular.module('customerApp').directive('portalCustomerMessages', function(SERVER_CONFIG) {

	function link(scope, element, attrs) {
		scope.alerts = SERVER_CONFIG.MESSAGES;

		scope.closeAlert = function(index) {
			scope.alerts.splice(index, 1);
		};
	};

	return {
    	restrict: 'E',
    	templateUrl: 'assets/ng/view/customer-messages.html',
    	scope: { data: '=data' },
    	link: link
  	};

});
