'use strict';

angular.module('customerApp', ['ngRoute', 'ui.bootstrap', 'ngResource', 'flow', 'pascalprecht.translate', 'tmh.dynamicLocale'])

	.constant("SERVER_CONFIG", {
//		"ADMIN_SERVER_URL": 'http://www.revolua.com/global-detecta-api/rest/customer',
//		"OAUTH2_SERVER_URL": 'http://www.revolua.com/global-detecta-api',
		"OAUTH2_SERVER_URL": 'http://localhost:8888/global-detecta-api',
        "ADMIN_SERVER_URL": 'http://localhost:8888/global-detecta-api/rest/customer',
		"OAUTH2_CLIENT_ID": 'globaldetectaapp',
		"OAUTH2_CLIENT_SECRET": 'globaldetecta123456',
		"OAUTH2_GRANT_TYPE": 'password',
		"OAUTH2_SCOPE": 'read write',
        "MOCK": false,
        "XSRF_HEADER_NAME": 'app-xsrf-token',
        "XSRF_COOKIE_NAME": 'app-xsrf-cookie',
		"LOCAL_STORAGE_TOKEN_KEY": 'CUSTOMER_TOKEN',
		"TYPING_DEBOUNCE": 500,
		"CRUMBS": [
	        { 'title': 'Home', 'url': '#/', 'description': 'Go Home...', 'isActive': true }
    	],
    	"CURRENT_USER_DATA": {},
		"MESSAGES": [],
		"MENUS": [
            { 'url': '#/evaluators', 'title': 'Gerenciar usuários'}
		],
		"LOCALES":[
			{name: 'English', id: 'en-us', imgSrc: './assets/img/UK-flag-icon.png' },
	    	{name: 'Portuguese', id: 'pt-pt', imgSrc: './assets/img/Brazil-Flag-icon.png'},
		],
		PREFERRED_LOCALE: {name: 'English', id: 'en-us' }
    })

    .factory('loginInterceptor', function ($q, $window, $location, SERVER_CONFIG) {
		var responseUnauthorizedStatus = [400, 401, 403];
    	return {
			request: function(config) {
				var token = $window.localStorage[SERVER_CONFIG.LOCAL_STORAGE_TOKEN_KEY];
				if (token && token.indexOf('access_token') >= 0)
					config.headers['Authorization'] = 'Bearer ' + JSON.parse(token).access_token;
				return config;
			},
			response: function(config) {
				return config;
			},
			responseError: function(config) {
				SERVER_CONFIG.MESSAGES.splice(0, SERVER_CONFIG.MESSAGES.length);
				if (config && config.status == 0) {
					SERVER_CONFIG.MESSAGES.push({
						type: 'danger',
						msg: 'Server Unavaliable!!!'
					});
					$location.path('/login');
					return config;
				} else if (config && (responseUnauthorizedStatus.indexOf(config.status) !== -1)) {
					SERVER_CONFIG.MESSAGES.push({
						type: 'danger',
						msg: 'Access Denied, please check your user name and password!!!'
					});
					$location.path('/login');
					return config;
				} else {
					if (config && config.data && config.data.messages && config.data.messages.length) {
						angular.forEach(config.data.messages, function(message) {
							SERVER_CONFIG.MESSAGES.push({
								type: 'danger',
								msg: message
							});
						});
					} else {
						SERVER_CONFIG.MESSAGES.push({
							type: 'danger',
							msg: 'Ops, we have server problems'
						});
					}
				}
				return $q.reject(config.data);
			}
	   }
    })

	.config(['$httpProvider', function ($httpProvider) {
    	$httpProvider.defaults.useXDomain = true;
    	delete $httpProvider.defaults.headers.common['X-Requested-With'];
    	$httpProvider.interceptors.push('loginInterceptor');
	}]);

	angular.module('customerApp').config(function ($translateProvider, tmhDynamicLocaleProvider, SERVER_CONFIG) {
	  $translateProvider.translations('en-us', window.translations.en);
	  $translateProvider.translations('pt-pt', window.translations.pt);
	  $translateProvider.translations('pt-br', window.translations.pt);
  	  var browserLocale = window.navigator.language.toLowerCase();
	  var appLocales = SERVER_CONFIG.LOCALES.filter(function(locale) {
	  	return (locale.id == browserLocale);
	  });
	  var appLocaleId = SERVER_CONFIG.PREFERRED_LOCALE.id;
	  if (appLocales && appLocales.length > 0)  {
	  	appLocaleId = appLocales[0].id;
	  }
	  $translateProvider.preferredLanguage(appLocaleId);
	  tmhDynamicLocaleProvider.localeLocationPattern('https://code.angularjs.org/1.4.7/i18n/angular-locale_{{locale}}.js');
	});