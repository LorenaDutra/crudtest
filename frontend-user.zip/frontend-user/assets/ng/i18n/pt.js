
//TODO - Refatorar transformar em uma constante do angular.
window.translations = window.translations || {};

window.translations.pt = {

	//General Buttons
	Edit: 'Editar',
	Cancel: 'Cancelar',
	Save: 'Salvar',
	Confirm: 'Confirmar',

	//General Messages
	'Discard all changes?': 'Descartar todas as alterações?',
	'Password confirmation is incorrect': 'Confirmação de senha está incorreta',
	'Select the patient gender': 'Selecione o gênero do paciente',
	'Password required...': 'Password é obrigatório...',
	'Login required...': 'Login é obrigatório...',

	//Error Messages
	'Error getting the evaluator with id:': 'Erro ao pegar avaliador com o id:',
	'Error getting the patient with id:': 'Erro ao pegar paciente com o id:',

	//Successfull Messages
	'User saved successfully': 'Usuário salvo com sucesso',
	'Evaluator saved successfully': 'Avaliador salvo com sucesso',
	'Patient saved successfully': 'Paciente salvo com sucesso',

		//Remove Messages
	'Remove evaluator': 'Remover avaliador', 
	'Remove patient': 'Remover paciente', 
	'Attention! ALL THE EVALUATION FORMS RELATED TO THIS EVALUATOR WILL BE LOST. Proceed?': 'Atenção! TODOS OS FORMULÁRIOS DE AVALIAÇÕES RELACIONADOS A ESTE AVALIADOR SERÃO PERDIDOS. Prosseguir?',
	'Attention! ALL THE EVALUATION FORMS RELATED TO THIS PATIENT WILL BE LOST. Proceed?': 'Atenção! TODOS OS FORMULÁRIOS DE AVALIAÇÕES RELACIONADOS A ESTE PACIENTE SERÃO PERDIDOS. Prosseguir?',

	//Server Messages
	'Access Denied, please check your user name and password!!!': 'Acesso Negado, por favor verifique seu nome de usuário e senha!!!',
	'Server Unavaliable!!!': 'Servidor Indisponível',
	'Ops, we have server problems': 'Ops, estamos com problema no servidor',

	//Login
	'Remember me': 'Lembrar',

	//Main Page
	'Customer Area' : 'Área Cliente',
	Logout: 'Sair',
	'Manage Evaluator': 'Gerenciar Avaliador',
	'Manage Patient': 'Gerenciar Paciente',
	'Home': 'Página Inicial',

	//Profile
	User: 'Usuário',
	Photo: 'Foto',
	Code: 'ID',
	Password: 'Senha',
	Name: 'Nome',
	'Repeat password': 'Repetir senha',
	Email: 'Email',

	//List Panel
	'Search...': 'Buscar...',

	//List Panel Items
	Empty: 'Vazio',

	//List Panel Evaluator
	Evaluators: 'Avaliadores',

	//Evaluator form
	Evaluator: 'Avaliador',
	Code: 'ID',
	Name: 'Nome',
	Customer: 'Cliente',
	Description: 'Descrição',
	Password: 'Senha',
	'Repeat password': 'Repetir senha',
	Email: 'Email',
	

	//List Panel Patient
	Patients: 'Pacientes',

	//Patient form
	Patient: 'Paciente',
	Code: 'ID',
	Name: 'Nome',
	Customer: 'Cliente',
	Description: 'Descrição',
	'Birth Date': 'Data de Nascimento',
	Gender: 'Gênero',
	Female: 'Feminino',
	Male: 'Masculino',
	Address: 'Endereço',
	City: 'Cidade',
	'ZIP Code': 'CEP',
	Country: 'País',
	Telephone: 'Telefone',
	'Mobile Telephone': 'Celular',
	'E-mail Address': 'Email',
	'Refered by': 'Referenciado por',
	'Insurance': 'Convênio saúde',
	'Main Complaint Description': 'Descrição da reclamação principal',
	Password: 'Senha',
	'Repeat password': 'Repetir senha',

}


