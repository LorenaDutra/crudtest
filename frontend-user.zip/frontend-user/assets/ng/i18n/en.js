
//TODO - Refatorar transformar em uma constante do angular.
window.translations = window.translations || {};

window.translations.en = {

	//General Buttons
	Editar: 'Edit',
	Cancelar: 'Cancel',
	Salvar: 'Save',
	Confirmar: 'Confirm',

	//General Messages
	'Descartar todas as alterações?': 'Discard all changes?',
	'Confirmação de senha está incorreta': 'Password confirmation is incorrect',
	'Selecione o gênero do paciente': 'Select the patient gender',
	'Password é obrigatório...': 'Password required...',
	'Login é obrigatório...': 'Login required...',

	//Error Messages
	'Erro ao pegar avaliador com o id:': 'Error getting the evaluator with id:',
	'Erro ao pegar paciente com o id:': 'Error getting the patient with id:',

	//Successfull Messages
	'Usuário salvo com sucesso': 'User saved successfully',
	'Avaliador salvo com sucesso': 'Evaluator saved successfully',
	'Paciente salvo com sucesso': 'Patient saved successfully',

	//Remove Messages
	'Remover avaliador': 'Remove evaluator', 
	'Remover paciente': 'Remove patient', 
	'Atenção! TODOS OS FORMULÁRIOS DE AVALIAÇÕES RELACIONADOS A ESTE AVALIADOR SERÃO PERDIDOS. Prosseguir?': 'Attention! ALL THE EVALUATION FORMS RELATED TO THIS EVALUATOR WILL BE LOST. Proceed?',
	'Atenção! TODOS OS FORMULÁRIOS DE AVALIAÇÕES RELACIONADOS A ESTE PACIENTE SERÃO PERDIDOS. Prosseguir?': 'Attention! ALL THE EVALUATION FORMS RELATED TO THIS PATIENT WILL BE LOST. Proceed?',

	//Server Messages
	'Acesso Negado, por favor verifique seu nome de usuário e senha!!!': 'Access Denied, please check your user name and password!!!',
	'Servidor Indisponível': 'Server Unavaliable!!!',
	'Ops, estamos com problema no servidor': 'Ops, we have server problems',

	//Login
	'Lembrar': 'Remember me',

	//Main Page
	'Área Cliente' : 'Customer Area',
	Sair: 'Logout',
	'Gerenciar Avaliador': 'Manage Evaluator',
	'Gerenciar Paciente': 'Manage Patient',
	'Página Inicial': 'Home',

	//Profile
	Usuário: 'User',
	Foto: 'Photo',
	ID: 'Code',
	Senha: 'Password',
	Nome: 'Name',
	'Repetir senha': 'Repeat password',
	Email: 'Email',

	//List Panel
	'Buscar...': 'Search...',

	//List Panel Items
	Vazio: 'Empty',

	//List Panel Evaluator
	Avaliadores: 'Evaluators',

	//Evaluator form
	Avaliador: 'Evaluator',
	ID: 'Code',
	Nome: 'Name',
	Cliente: 'Customer',
	Descrição: 'Description',
	Email: 'Email',
	Senha: 'Password',
	'Repetir senha': 'Repeat password',
	

	//List Panel Patient
	Pacientes: 'Patients',

	//Patient form
	Paciente: 'Patient',
	ID: 'Code',
	Nome: 'Name',
	Cliente: 'Customer',
	Descrição: 'Description',
	'Data de Nascimento': 'Birth Date',
	Gênero: 'Gender',
	Feminino: 'Female',
	Masculino: 'Male',
	Endereço: 'Address',
	Cidade: 'City',
	'CEP': 'ZIP Code',
	País: 'Country',
	Telefone: 'Telephone',
	'Celular': 'Mobile Telephone',
	'Email': 'Email',
	'Referenciado por': 'Refered by',
	'Convênio saúde': 'Insurance',
	'Descrição da Reclamação Principal': 'Main Complaint Description',
	Senha: 'Password',
	'Repetir senha': 'Repeat password',

}


