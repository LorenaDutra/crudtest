angular.module('customerApp').controller('EvaluatorListCtrl', function($window, $scope, $location, $route, $routeParams, AppService, EvaluatorService) {
  var edit,
	    remove;

  // Breadcrumbs
  $scope.evaluatorsCrumb = [
    { 'title': 'Usuarios', 'url': '#/evaluators', 'description': 'Evaluators...', 'isActive': true }
  ];

  // edit item action
  edit = function(id, callback, error) {
    EvaluatorService.get({id: id}, function(evaluator) {
      evaluator.editAction = edit;
      evaluator.deleteAction = remove;
      callback(evaluator);
      $location.path('/evaluator/'+id);
    }, function() {
      console.error('Error getting user with id:'+id);
    });
  };

  // Remove item action
  remove = function(id, callback, error) {
    AppService.confirm('Remove user', 'Attention! ALL THE EVALUATION FORMS RELATED TO THIS EVALUATOR WILL BE LOST. Proceed?', function() {
      EvaluatorService.delete({id: id}, function() {
        callback();
      });
    });
  };

  // Sets actions in items
  $scope.actions = function(items) {
    angular.forEach(items, function(item) {
      item.editAction = edit;
      item.removeAction = remove;
    });
  };

  // List panel props
  $scope.listPanelData = {
    title: 'Usuarios',

    list: {
      itemWrapper: function(item) {
        var descriptionFields = [
          item.id,
          item.name

        ];
        if(item.description) {
          descriptionFields.push(item.description);
        }
        return {
          id: item.id,
          title: item.name,
          "descriptionFields": descriptionFields
        };
      },
      items: []
    },

    filterAction: function(filter, callback, error){
        EvaluatorService.query({ 'filter': filter }, function(evaluators) {
        $scope.actions(evaluators);
        callback(evaluators);
      });
    },

    printAction: function(type, filter, event) {
      EvaluatorService.print(type, filter);
    },

    newAction: function(e) {
      console.log(e);
      $location.path('/evaluator');
    }
  };
  // Initial list
  EvaluatorService.query({filter: ''}, function(evaluators) {
    angular.copy(evaluators, $scope.listPanelData.list.items);
    $scope.actions($scope.listPanelData.list.items);
  });
});
