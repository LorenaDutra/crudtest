'use strict';

angular.module('customerApp').controller('LogoutCtrl', function($scope, $location, $route, $routeParams, AuthenticationService) {

	$scope.$route = $route;
    $scope.$location = $location;
    $scope.$routeParams = $routeParams;
     
    $scope.authenticationData = {
		rememberme: false,
		login: '',
		password: '',
		errormessages: []
    };

    $scope.logout = AuthenticationService.cleanLogin;

});
