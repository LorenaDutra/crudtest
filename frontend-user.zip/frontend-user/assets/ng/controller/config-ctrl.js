'use strict';

angular.module('customerApp').controller('ConfigCtrl', function($scope, $location, $route, $routeParams, AuthenticationService, ConfigurationService) {

	$scope.$route = $route;
    $scope.$location = $location;
    $scope.$routeParams = $routeParams;

    $scope.appdata = {
    	headerData: {},
    	homeData: {},
    	footerData: {},
        configdata: {}
    };

    ConfigurationService.query({}, function(configList) {
        $scope.appdata.configdata.configList = configList;
    });

    if (!AuthenticationService.isAuthenticated())
        $location.path('/login');

    $scope.isAuthenticated = function() {
        return AuthenticationService.isAuthenticated();
    };
    
});
