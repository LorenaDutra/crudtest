angular.module('customerApp').controller('EvaluatorFormCtrl', function($window, $scope, $location, $route, $routeParams, AppService, EvaluatorService) {

  $scope.model = {
    user: {}
  };

  $scope.evaluatorCrumb = [
    { 'title': 'Evaluators', 'url': '#/evaluators', 'description': 'Evaluators...', 'isActive': false },
    { 'title': 'Evaluator', 'url': '#/evaluator', 'description': 'Evaluator...', 'isActive': true }
  ];

  // Edit
  $scope.inEdition = $routeParams.id ? parseInt($routeParams.id) : null;
  if ($scope.inEdition) {
    EvaluatorService.get({id: $scope.inEdition}, function(evaluator) {
      angular.copy(evaluator, $scope.model);
      $scope.model.user = {};
      angular.copy(evaluator.user, $scope.model.user);
    });
  }

  // Save/Edit user
  $scope.save = function() {
    $scope.validate();

    if (! $scope.evaluatorForm.$valid) {
      return;
    }

    if($scope.inEdition) {
      EvaluatorService.update($scope.model, function() {
        AppService.addSuccessMessage('User saved Successfully');
        $location.path('/evaluators');
      });
    } else {
      EvaluatorService.save($scope.model, function() {
        AppService.addSuccessMessage('User saved successfully');
        $location.path('/evaluators');
      });
    }
  };

  $scope.cancel = function() {
    AppService.confirm('Cancel', 'Discard all changes?', function() {
      $location.path('/evaluators');
    });
  };

  $scope.validate = function() {
    angular.forEach($scope.evaluatorForm.$error.required, function(field) {
      field.$setTouched();
    });
  };

  $scope.loginModified = false;
  $scope.isPasswordRequired = function() {
    return $scope.model.user.login && (!$scope.inEdition || $scope.loginModified);
  };

  $scope.verifyPassword = function() {
    var password = $scope.model.user.password,
        confirm = $scope.model.passwordConfirm;

    if (! (password && confirm)) {
      return;
    }

    if (password !== confirm) {
      $scope.model.user.password = $scope.model.passwordConfirm = '';
      AppService.addErrorMessage('Password confirmation is incorrect');
    }
  };

});
