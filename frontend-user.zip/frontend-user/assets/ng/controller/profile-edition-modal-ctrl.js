angular.module('customerApp').controller('ProfileEditionModalCtrl', function($scope, $uibModalInstance, $location, SERVER_CONFIG, AppService, AuthenticationService, UserService) {

    $scope.title = AppService.profileEditionModal.title;
    $scope.message = AppService.profileEditionModal.message;
    $scope.model = {};

    //Gets the logged user
    AuthenticationService.getCurrentUser({}, function(currentUser) {
	    angular.copy(currentUser, $scope.model);
	}, function(error) {
	    $location.path('#/login');
	});

    $scope.setAvatar = function(file) {
        var reader = new FileReader();
        reader.readAsDataURL(file.file);
        reader.onloadend = function() {
          $scope.$apply(function() {
            $scope.model.avatar = reader.result;
          });
        };
    };

	$scope.save = function() {
	    $scope.validate();
	    if (! $scope.userModalForm.$valid) {
	      return AppService.addErrorMessages();
	    }
	    UserService.update($scope.model, function(data) {
		    angular.copy(data, SERVER_CONFIG.CURRENT_USER_DATA);
	      	$uibModalInstance.close(AppService.addSuccessMessage('User saved successfully'));
	    }, function(data) {
   			console.log(data);
	    });
  	};

  	$scope.validate = function() {
	    angular.forEach($scope.userModalForm.$error.required, function(field) {
	      field.$setTouched();
	    });
  	};

  	//Changes the perfil's picture
	$scope.changeImage = function( $file, $event, $flow ) {
        $flow.files.splice(0, $flow.files.length);
    };

    //Closes modal
	$scope.cancel = function () {
		if (AppService.profileEditionModal.cancel) {
			AppService.profileEditionModal.cancel();
		}
		AppService.profileEditionModal.visible = false;
		$uibModalInstance.dismiss('cancel');
	};
});
