'use strict';

angular.module('customerApp').controller('LoginCtrl', function($scope, $location, $route, $routeParams, SERVER_CONFIG) {

	$scope.$route = $route;
    $scope.$location = $location;
    $scope.$routeParams = $routeParams;
     
    $scope.appdata = {
    	authenticationData: {
			rememberme: false,
			login: '',
			password: '',
			errormessages: []
    	}
    };

});
