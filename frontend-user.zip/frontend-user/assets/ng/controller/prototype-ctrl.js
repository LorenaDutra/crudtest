'use strict';

angular.module('customerApp').controller('PrototypeCtrl', function($window, $scope, $location, $route, $routeParams, UserService, SERVER_CONFIG) {
	var edit,
	    remove;

	$scope.$route = $route;
    $scope.$location = $location;
    $scope.$routeParams = $routeParams;
    $scope.$window = $window;

    $scope.appdata = {
    	headerData: {},
    	homeData: {},
    	footerData: {},
        configdata: {}
    };

    $scope.usersCrumb = [
        { 'title': 'Users', 'url': '#/prototype/users', 'description': 'Users...', 'isActive': true }
    ];

    $scope.userCrumb = [
        { 'title': 'Users', 'url': '#/prototype/users', 'description': 'Users...', 'isActive': false },
        { 'title': 'User', 'url': '#/prototype/user', 'description': 'User...', 'isActive': true }
    ];


    $scope.customersCrumb = [
        { 'title': 'Customers', 'url': '#/prototype/customers', 'description': 'Customers...', 'isActive': true }
    ];

    $scope.customerCrumb = [
        { 'title': 'Customers', 'url': '#/prototype/customers', 'description': 'Customers...', 'isActive': false },
        { 'title': 'Customer', 'url': '#/prototype/customer', 'description': 'Customers...', 'isActive': true }
    ];

    $scope.evaluationsCrumb = [
        { 'title': 'Evaluation-forms', 'url': '#/prototype/evaluation-forms', 'description': 'Evaluation-forms...', 'isActive': true }
    ];

    $scope.evaluationCrumb = [
        { 'title': 'Evaluation-forms', 'url': '#/prototype/evaluation-forms', 'description': 'Evaluation-forms...', 'isActive': false },
        { 'title': 'Evaluation-form', 'url': '#/prototype/evaluation-form', 'description': 'Evaluation-form...', 'isActive': true }
    ];

    $scope.evaluatorsCrumb = [
        { 'title': 'Evaluators', 'url': '#/prototype/evaluators', 'description': 'Evaluators...', 'isActive': true }
    ];

    $scope.evaluatorCrumb = [
        { 'title': 'Evaluators', 'url': '#/prototype/evaluators', 'description': 'Evaluators...', 'isActive': false },
        { 'title': 'Evaluator', 'url': '#/prototype/evaluator', 'description': 'Evaluator...', 'isActive': true }
    ];

    $scope.parametersCrumb = [
        { 'title': 'Parameters', 'url': '#/prototype/parameters', 'description': 'Parameters...', 'isActive': true }
    ];

    $scope.parameterCrumb = [
        { 'title': 'Parameters', 'url': '#/prototype/parameters', 'description': 'Parameters...', 'isActive': false },
        { 'title': 'Parameter', 'url': '#/prototype/parameter', 'description': 'Parameter...', 'isActive': true }
    ];

    $scope.surveysCrumb = [
        { 'title': 'Survey-forms', 'url': '#/prototype/survey-forms', 'description': 'Surveys...', 'isActive': true }
    ];

    $scope.surveyCrumb = [
        { 'title': 'Survey-forms', 'url': '#/prototype/survey-forms', 'description': 'Surveys...', 'isActive': false },
        { 'title': 'Survey-form', 'url': '#/prototype/survey-form', 'description': 'Survey...', 'isActive': true }
    ];

    $scope.providersCrumb = [
        { 'title': 'Providers', 'url': '#/prototype/providers', 'description': 'Providers...', 'isActive': true }
    ];

    $scope.providerCrumb = [
        { 'title': 'Providers', 'url': '#/prototype/providers', 'description': 'Providers...', 'isActive': false },
        { 'title': 'Provider', 'url': '#/prototype/provider', 'description': 'Provider...', 'isActive': true }
    ];

		edit = function(id, callback, error) {
			console.log('Edit '+id);
			callback({id: id, name: 'Leopard', editAction: edit, deleteAction: remove});
			$location.path('/prototype/user/'+id);
		};

		remove = function(id, callback, error) {
			console.log('Delete '+id);
			callback();
		};

		$scope.adminListPanelSample = {
			title: 'Users',
			list: {
				itemWrapper: function(item) {
					return {
						id: item.id,
						title: item.name,
						descriptionFields: [
							'bite',
							'scratch',
							'roar'
						]
					};
				},
				items: [
					{id: 1, name: 'Leopard', editAction: edit, deleteAction: remove},
					{id: 2, name: 'Lion', editAction: edit, deleteAction: remove},
					{id: 55, name: 'Lynx', editAction: edit, deleteAction: remove}
				]
			},
			filterAction: function(filter, callback, error){
				console.log('Filter:');
				console.log(filter);

				console.log('Callback:');
				console.log(callback);

				console.log('Error:');
				console.log(error);
			},
			printAction: function(type, filter, event) {
				console.log('Type:');
				console.log(type);

				console.log('Filter:');
				console.log(filter);

				console.log('Event:');
				console.log(event);
			},
			newAction: function(e) {
				console.log(e);
				$location.path('/prototype/user');
			}
		};

});
