'use strict';

angular.module('customerApp').controller('MainCtrl', function($scope, $location, $route, $routeParams, AuthenticationService) {

	$scope.$route = $route;
  $scope.$location = $location;
  $scope.$routeParams = $routeParams;

  $scope.appdata = {
  	headerData: {},
  	homeData: {},
  	footerData: {}
  };
  
});
