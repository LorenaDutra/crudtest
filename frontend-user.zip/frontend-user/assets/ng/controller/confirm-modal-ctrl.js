// Confirm modal controller
angular.module('customerApp').controller('ConfirmModalCtrl', function($scope, $uibModalInstance, AppService) {

  $scope.title = AppService.confirmModal.title;
  $scope.message = AppService.confirmModal.message;

	$scope.ok = function () {
		AppService.confirmModal.ok();
    $uibModalInstance.dismiss('cancel');
	};

	$scope.cancel = function () {
		if (AppService.confirmModal.cancel) {
			AppService.confirmModal.cancel();
		}
		AppService.confirmModal.visible = false;
		$uibModalInstance.dismiss('cancel');
	};
});
