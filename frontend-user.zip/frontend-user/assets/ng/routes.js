'use strict';

angular.module('customerApp').config(function($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'assets/ng/view/prototype-home.html',
        controller: 'PrototypeCtrl'
      })

      // Authentication
      .when('/login', {
        templateUrl: 'assets/ng/view/login.html',
        controller: 'LoginCtrl'
      })
      .when('/logout', {
        templateUrl: 'assets/ng/view/logout.html',
        controller: 'LogoutCtrl'
      })

      // Configuration
      .when('/config', {
        templateUrl: 'assets/ng/view/config.html',
        controller: 'ConfigCtrl'
      })

      // CRUD
      .when('/users', {
        templateUrl: 'assets/ng/view/users.html',
        controller: 'UserListCtrl'
      })
      .when('/user', {
        templateUrl: 'assets/ng/view/user.html',
        controller: 'UserFormCtrl'
      })
      .when('/user/:id', {
        templateUrl: 'assets/ng/view/user.html',
        controller: 'UserFormCtrl'
      })

      .when('/evaluators', {
        templateUrl: 'assets/ng/view/evaluators.html',
        controller: 'EvaluatorListCtrl'
      })
      .when('/evaluator', {
        templateUrl: 'assets/ng/view/evaluator.html',
        controller: 'EvaluatorFormCtrl'
      })
      .when('/evaluator/:id', {
        templateUrl: 'assets/ng/view/evaluator.html',
        controller: 'EvaluatorFormCtrl'
      })
      .when('/patients', {
        templateUrl: 'assets/ng/view/patients.html',
        controller: 'PatientListCtrl'
      })
      .when('/patient', {
        templateUrl: 'assets/ng/view/patient.html',
        controller: 'PatientFormCtrl'
      })
      .when('/patient/:id', {
        templateUrl: 'assets/ng/view/patient.html',
        controller: 'PatientFormCtrl'
      })

      .when('/customers', {
        templateUrl: 'assets/ng/view/customers.html',
        controller: 'CustomerListCtrl'
      })
      .when('/customer', {
        templateUrl: 'assets/ng/view/customer.html',
        controller: 'CustomerFormCtrl'
      })
      .when('/customer/:id', {
        templateUrl: 'assets/ng/view/customer.html',
        controller: 'CustomerFormCtrl'
      })

      //PROTOTYPE LIST ROUTES
      .when('/prototype/users', {
        templateUrl: 'assets/ng/view/prototype-users.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/user', {
        templateUrl: 'assets/ng/view/prototype-user.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/user/:id', {
        templateUrl: 'assets/ng/view/prototype-user.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/parameters', {
        templateUrl: 'assets/ng/view/prototype-parameters.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/evaluation-forms', {
        templateUrl: 'assets/ng/view/prototype-evaluation-forms.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/survey-forms', {
        templateUrl: 'assets/ng/view/prototype-survey-forms.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/providers', {
        templateUrl: 'assets/ng/view/prototype-providers.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/customers', {
        templateUrl: 'assets/ng/view/prototype-customers.html',
        controller: 'PrototypeCtrl'
      })

      .when('/prototype/evaluators', {
        templateUrl: 'assets/ng/view/prototype-evaluators.html',
        controller: 'PrototypeCtrl'
      })

      .when('/prototype/home', {
        templateUrl: 'assets/ng/view/prototype-home.html',
        controller: 'PrototypeCtrl'
      })
      //PROTOTYPE NEW/EDIT ROUTES
      .when('/prototype/user', {
        templateUrl: 'assets/ng/view/prototype-user.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/user/:id', {
        templateUrl: 'assets/ng/view/prototype-user.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/parameter', {
        templateUrl: 'assets/ng/view/prototype-parameter.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/parameter/:id', {
        templateUrl: 'assets/ng/view/prototype-parameter.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/evaluation-form', {
        templateUrl: 'assets/ng/view/prototype-evaluation-form.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/evaluation-form/:id', {
        templateUrl: 'assets/ng/view/prototype-evaluation-form.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/survey-form', {
        templateUrl: 'assets/ng/view/prototype-survey-form.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/survey-form/:id', {
        templateUrl: 'assets/ng/view/prototype-survey-form.html',
        controller: 'PrototypeCtrl'
      })

      .when('/prototype/customer', {
        templateUrl: 'assets/ng/view/prototype-customer.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/customer/:id', {
        templateUrl: 'assets/ng/view/prototype-customer.html',
        controller: 'PrototypeCtrl'
      })

      .when('/prototype/evaluator', {
        templateUrl: 'assets/ng/view/prototype-evaluator.html',
        controller: 'PrototypeCtrl'
      })
      .when('/prototype/evaluator/:id', {
        templateUrl: 'assets/ng/view/prototype-evaluator.html',
        controller: 'PrototypeCtrl'
      })

      //DEFAULT ROUTE
      .otherwise({
        templateUrl: 'assets/ng/view/prototype-home.html',
        controller: 'PrototypeCtrl'
      });
  });
