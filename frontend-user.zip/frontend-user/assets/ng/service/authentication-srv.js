'use strict';

angular.module('customerApp').service('AuthenticationService', function ($window, $http, $resource, SERVER_CONFIG, AppService, $timeout) {
	var cleanLogin = function() {
		$window.localStorage[SERVER_CONFIG.LOCAL_STORAGE_TOKEN_KEY] = '';
		angular.copy({}, SERVER_CONFIG.CURRENT_USER_DATA);
	};
	var setLoginToken = function(token) {
		$window.localStorage[SERVER_CONFIG.LOCAL_STORAGE_TOKEN_KEY] = token;
	};

	var resource = {};

	if (SERVER_CONFIG.MOCK) {
		var _currentUser = {
			'id': 1,
			'password': 'Password',
			'name': '',
			'email': ''
		};
		resource = {
			'login': function(form, success, error) {
				success({token: '1234ASD123ASD'});
			},
			'logout': function(form, success, error) {
				if (success)
					success({});
			},
			'getCurrentUser' : function(data, callback, error) {
				var userdata = {};
				angular.copy(_currentUser, userdata);
				$timeout(1, callback(userdata));
			},
			'updateProfile': function(data, callback, error) {
				angular.copy(data, _currentUser);
				$timeout(1, callback(data));
			}
		};
	} else {

		resource.login = function(user, success, error) {
			cleanLogin();
			AppService.clearMessages();
			var data = {
					"username": user.login,
					"password": user.password,
					"grant_type": SERVER_CONFIG.OAUTH2_GRANT_TYPE,
					"scope": SERVER_CONFIG.OAUTH2_SCOPE,
					"client_id": SERVER_CONFIG.OAUTH2_CLIENT_ID,
					"client_secret": SERVER_CONFIG.OAUTH2_CLIENT_SECRET
			};
			var authorization = 'Basic ' + btoa(SERVER_CONFIG.OAUTH2_CLIENT_ID + ':' + SERVER_CONFIG.OAUTH2_CLIENT_SECRET);
			var headers = {
				"Content-Type": 'application/x-www-form-urlencoded; charset=UTF-8',
				"Authorization": authorization
			};
			$http.post(SERVER_CONFIG.OAUTH2_SERVER_URL + '/oauth/token', $.param(data), {"headers": headers}).then(
				function(data) {
					$window.localStorage[SERVER_CONFIG.LOCAL_STORAGE_TOKEN_KEY] = JSON.stringify(data.data);
					resource.getCurrentUser();
					if (success)
						success(data);
				}, function(data) {
					$window.localStorage[SERVER_CONFIG.LOCAL_STORAGE_TOKEN_KEY] = '';
					if (error)
						error(data);
			});
		};

		resource.getCurrentUser = function(data, callback, error) {
			if (SERVER_CONFIG.CURRENT_USER_DATA.username) {
				if (callback) {
					return callback(SERVER_CONFIG.CURRENT_USER_DATA);
				}
			}
			return $http.get(SERVER_CONFIG.ADMIN_SERVER_URL + '/current-user')
			.then(function(response) {
				angular.copy(response.data, SERVER_CONFIG.CURRENT_USER_DATA);
				if (callback) {
					callback(response.data);
				}
			}, error);
		};

	}

	resource.cleanLogin = cleanLogin;
	resource.setLoginToken = setLoginToken;

	return resource;
});
