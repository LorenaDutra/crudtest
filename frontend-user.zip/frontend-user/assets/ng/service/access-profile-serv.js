'use strict';

angular.module('customerApp').service('AccessProfileService', function ($http, $resource, $timeout, AppService, SERVER_CONFIG) {
	if (SERVER_CONFIG.MOCK) {
		
		var _accessProfiles = [];

		return {

		}

	} else {

		var resource = $resource(SERVER_CONFIG.ADMIN_SERVER_URL + '/accessProfile', {}, {
			'query': {
				url: SERVER_CONFIG.ADMIN_SERVER_URL + '/accessProfile/query',
				method: 'POST',
				isArray: true
			}
		});
		return resource;
	}
}