'use strict';

angular.module('customerApp').service('AppService', function ($http, $resource, $uibModal, $translate, tmhDynamicLocale, SERVER_CONFIG) {
	var resource = {};
	if (SERVER_CONFIG.MOCK) {
		//Mock Usage
	} else {
		//Server Usage
	}
	resource.pushCrumb = function(crumb) {
    	SERVER_CONFIG.CRUMBS.push(crumb);
    	angular.forEach(SERVER_CONFIG.CRUMBS, function(item) {
    		item.isActive = false;
    	});
    	crumb.isActive = true;
    };

    resource.resetCrumbs = function() {
    	SERVER_CONFIG.CRUMBS.splice(1, SERVER_CONFIG.CRUMBS.length);
    	SERVER_CONFIG.CRUMBS[0].isActive = true;
    };

    resource.confirmModal = { };

    resource.confirm = function(title, message, ok, cancel) {
		var confirmModal = {
			title: title,
			message: message,
			ok: ok,
			cancel: cancel,
			visible: true
		};
		angular.copy(confirmModal, this.confirmModal);
		$uibModal.open({
		      			templateUrl: 'confirm-modal-template',
    	  				controller: 'ConfirmModalCtrl',
						size: 'sm'
	    			});
	};

	resource.profileEditionModal = {};

	resource.openProfileEdition = function(cancel) {
		this.profileEditionModal.cancel = cancel;
		this.profileEditionModal.visible = true;
		$uibModal.open({
		      			templateUrl: 'assets/ng/view/profile-edition-modal.html',
    	  				controller: 'ProfileEditionModalCtrl',
						size: 'lg'
	    			});
	};

	resource.downloadFile = function(url) {
		var a = document.createElement('a');
		a.href = url;
		a.download = url.split('/').pop();
		a.target = '_blank';
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
	};
	resource.addSuccessMessage = function(message) {
		SERVER_CONFIG.MESSAGES.push({
			type: 'success',
			msg: message
		});
	};
	resource.addSuccessMessages = function(messages) {
        if (messages)
        	angular.forEach(messages, function(message) {
            	resource.addSuccessMessage(message);
          	});
	};
	resource.addErrorMessage = function(message) {
		SERVER_CONFIG.MESSAGES.push({
			type: 'danger',
			msg: message
		});
	};
	resource.addErrorMessages = function(messages) {
        if (messages)
        	angular.forEach(messages, function(message) {
            	resource.addErrorMessage(message);
          	});
	};
	resource.addInfoMessage = function(message) {
		SERVER_CONFIG.MESSAGES.push({
			type: 'info',
			msg: message
		});
	};
	resource.addInfoMessages = function(messages) {
        if (messages)
        	angular.forEach(messages, function(message) {
            	resource.addInfoMessage(message);
          	});
	};
	resource.clearMessages = function() {
		SERVER_CONFIG.MESSAGES.splice(0, SERVER_CONFIG.MESSAGES.length);
	};

	resource.setLocale = function(id) {
	  var appLocales = SERVER_CONFIG.LOCALES.filter(function(locale) {
	  	return (locale.id == id);
	  });
	  var appLocaleId = SERVER_CONFIG.PREFERRED_LOCALE.id;
	  if (appLocales && appLocales.length > 0)  {
	  	appLocaleId = appLocales[0].id;
	  }
	  tmhDynamicLocale.set(appLocaleId);
      $translate.use(appLocaleId);
	};
	
	return resource;
});

