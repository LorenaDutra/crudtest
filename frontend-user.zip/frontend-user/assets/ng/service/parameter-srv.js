'use strict';

angular.module('customerApp').service('ParameterService', function ($http, $resource, $timeout, AppService, SERVER_CONFIG) {
	if (SERVER_CONFIG.MOCK) {

		var _parameters = [];

		return {
			'load': function(callback) {
				if (!this.loaded) {
					$http.get('assets/ng/mock/parameters.json').then(function(response) {
						this.loaded = true;
						angular.copy(response.data, _parameters);
						$timeout(callback, 1);
					}.bind(this));
				} else {
					$timeout(callback, 1);
				}
			},
			'get': function(parameter, success, error) {
				var parameterRet = {};
				this.load(function() {
					angular.forEach(_parameters, function(pParameter) {
						if (pParameter.id === parameter.id)
							angular.copy(pParameter, parameterRet);
					});
					$timeout(function() {
						success(parameterRet);
					}, 1);
				});
			},
			'save': function(parameter, success, error) {
				// Update
				if (parameter.id) {
					for (var i in _parameters) {
						if (_parameters[i].id === parameter.id) {
							angular.copy(parameter, _parameters[i]);
							return $timeout(success, 1);
						}
					}
				}
				parameter.id = _parameters.length + 1;

				// Create
				_parameters.push(parameter);
				$timeout(success, 1);
			},
			'remove': function(parameter, success, error) {
				var pos;
				for (var i in _parameters) {
					if (_parameters[i].id === parameter.id) {
						pos = i;
					}
				}
				if (pos) {
					_parameters.splice(pos, 1);
					return $timeout(success, 1);
				}
				return $timeout(error, 1);
			},
			'delete': function(parameter, success, error) {
				return this.remove(parameter, success, error);
			},
			'query': function(filter, success, error) {
				this.load(function() {
					var ret = [];
					angular.copy(_parameters.filter(function(parameter) {
						if (filter && filter.filter && parameter && parameter.name)
							return parameter.name.toUpperCase().indexOf(filter.filter.toUpperCase()) > -1;
						else
							return true;
					}), ret);
					$timeout(function() {
						success(ret);
					}, 1);
				});
			},
			'print': function(type, filter) {
				AppService.downloadFile('assets/ng/mock/print/file.' + type.toLowerCase());
			}
		};
	} else {

		var resource = $resource(SERVER_CONFIG.ADMIN_SERVER_URL + '/parameter', {}, {
			'query': {
				url: SERVER_CONFIG.ADMIN_SERVER_URL + '/parameter/query',
				method: 'POST',
				isArray: true
			}
		});
		return resource;
	}
});
