'use strict';

angular.module('customerApp').service('SurveyFormService', function ($http, $resource, $timeout, AppService, SERVER_CONFIG) {
	if (SERVER_CONFIG.MOCK) {

		var _surveys = [];

		return {
			'load': function(callback) {
				if (!this.loaded) {
					$http.get('assets/ng/mock/survey-forms.json').then(function(response) {
						this.loaded = true;
						angular.copy(response.data, _surveys);
						$timeout(callback, 1);
					}.bind(this));
				} else {
					$timeout(callback, 1);
				}
			},
			'get': function(survey, success, error) {
				var surveyRet = {};
				this.load(function() {
					angular.forEach(_surveys, function(pSurvey) {
						if (pSurvey.id === survey.id)
							angular.copy(pSurvey, surveyRet);
					});
					$timeout(function() {
						success(surveyRet);
					}, 1);
				});
			},
			'save': function(survey, success, error) {
				// Update
				if (survey.id) {
					for (var i in _surveys) {
						if (_surveys[i].id === survey.id) {
							angular.copy(survey, _surveys[i]);
							return $timeout(success, 1);
						}
					}
				}

				// Create
				survey.id = _surveys.length + 1;
				_surveys.push(survey);
				$timeout(success, 1);
			},
			'remove': function(survey, success, error) {
				var pos;
				for (var i in _surveys) {
					if (_surveys[i].id === survey.id) {
						pos = i;
					}
				}
				if (pos) {
					_surveys.splice(pos, 1);
					return $timeout(success, 1);
				}
				return $timeout(error, 1);
			},
			'delete': function(survey, success, error) {
				return this.remove(survey, success, error);
			},
			'query': function(filter, success, error) {
				this.load(function() {
					var ret = [];
					angular.copy(_surveys.filter(function(survey) {
						if (filter && filter.filter && survey && survey.name)
							return survey.name.toUpperCase().indexOf(filter.filter.toUpperCase()) > -1;
						else
							return true;
					}), ret);
					$timeout(function() {
						success(ret);
					}, 1);
				});
			},
			'print': function(type, filter) {
				AppService.downloadFile('assets/ng/mock/print/file.' + type.toLowerCase());
			}
		};
	} else {

		var resource = $resource(SERVER_CONFIG.ADMIN_SERVER_URL + '/survey', {}, {
			'query': {
				url: SERVER_CONFIG.ADMIN_SERVER_URL + '/survey-forms/query',
				method: 'POST',
				isArray: true
			},
			'print': function(type, filter) {
				AppService.downloadFile(SERVER_CONFIG.ADMIN_SERVER_URL + '/survey-forms/file.' + type.toLowerCase());
			}
		});
		return resource;
	}
});
