'use strict';

angular.module('customerApp').service('EvaluatorService', function ($http, $resource, $timeout, AppService, SERVER_CONFIG) {
	if (SERVER_CONFIG.MOCK) {

		var _evaluators = [];

		return {
			'load': function(callback) {
				if (!this.loaded) {
					$http.get('assets/ng/mock/evaluators.json').then(function(response) {
						this.loaded = true;
						angular.copy(response.data, _evaluators);
						$timeout(callback, 1);
					}.bind(this));
				} else {
					$timeout(callback, 1);
				}
			},
			'get': function(evaluator, success, error) {
				var evaluatorRet = {};
				this.load(function() {
					angular.forEach(_evaluators, function(pEvaluator) {
						if (pEvaluator.id === evaluator.id)
							angular.copy(pEvaluator, evaluatorRet);
					});
					$timeout(function() {
						success(evaluatorRet);
					}, 1);
				});
			},
			'save': function(evaluator, success, error) {
				// Update
				if (evaluator.id) {
					for (var i in _evaluators) {
						if (_evaluators[i].id === evaluator.id) {
							angular.copy(evaluator, _evaluators[i]);
							return $timeout(success, 1);
						}
					}
				}
				evaluator.id = _evaluators.length + 1;

				// Create
				_evaluators.push(evaluator);
				return $timeout(success, 1);
			},
			'remove': function(evaluator, success, error) {
				var pos;
				for (var i in _evaluators) {
					if (_evaluators[i].id === evaluator.id) {
						pos = i;
					}
				}
				if (pos) {
					_evaluators.splice(pos, 1);
					return $timeout(success, 1);
				}
				return $timeout(error, 1);
			},
			'delete': function(evaluator, success, error) {
				return this.remove(evaluator, success, error);
			},
			'query': function(filter, success, error) {
				this.load(function() {
					var ret = [];
					angular.copy(_evaluators.filter(function(evaluator) {
						if (filter && filter.filter && evaluator && evaluator.name)
							return evaluator.name.toUpperCase().indexOf(filter.filter.toUpperCase()) > -1;
						else
							return true;
					}), ret);
					$timeout(function() {
						success(ret);
					}, 1);
				});
			},
			'print': function(type, filter) {
				AppService.downloadFile('assets/ng/mock/print/file.' + type.toLowerCase());
			}
		};
	} else {

		var resource = $resource(SERVER_CONFIG.ADMIN_SERVER_URL + '/evaluator', {}, {
			'query': {
				url: SERVER_CONFIG.ADMIN_SERVER_URL + '/evaluator/query',
				method: 'POST',
				isArray: true
			},
			'print': function(type, filter) {
				AppService.downloadFile('assets/ng/mock/print/file.' + type.toLowerCase());
			},
			'update': {method: 'PUT'}
		});
		return resource;
	}
});