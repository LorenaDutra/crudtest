'use strict';

angular.module('customerApp').service('UserService', function ($http, $resource, $timeout, AppService, SERVER_CONFIG) {
	if (SERVER_CONFIG.MOCK) {

		var _users = [];

		return {
			'load': function(callback) {
				if (!this.loaded) {
					$http.get('assets/ng/mock/users.json').then(function(response) {
						this.loaded = true;
						angular.copy(response.data, _users);
						$timeout(callback, 1);
					}.bind(this));
				} else {
					$timeout(callback, 1);
				}
			},
			'get': function(user, success, error) {
				var userRet = {};
				this.load(function() {
					angular.forEach(_users, function(pUser) {
						if (pUser.id === user.id)
							angular.copy(pUser, userRet);
					});
					$timeout(function() {
						success(userRet);
					}, 1);
				});
			},
			'save': function(user, success, error) {
				// Update
				if (user.id) {
					for (var i in _users) {
						if (_users[i].id === user.id) {
							angular.copy(user, _users[i]);
							return $timeout(success, 1);
						}
					}
				}
				user.id = _users.length + 1;
				// Create
				_users.push(user);
				$timeout(success, 1);
			},
			'remove': function(user, success, error) {
				var pos;
				for (var i in _users) {
					if (_users[i].id === user.id) {
						pos = i;
					}
				}
				if (pos) {
					_users.splice(pos, 1);
					return $timeout(success, 1);
				}
				return $timeout(error, 1);
			},
			'delete': function(user, success, error) {
				return this.remove(user, success, error);
			},
			'query': function(filter, success, error) {
				this.load(function() {
					var ret = [];
					angular.copy(_users.filter(function(user) {
						if (filter && filter.filter && user && user.login)
							return user.login.toUpperCase().indexOf(filter.filter.toUpperCase()) > -1;
						else
							return true;
					}), ret);
					$timeout(function() {
						success(ret);
					}, 1);
				});
			},
			'print': function(type, filter) {
				AppService.downloadFile('assets/ng/mock/print/file.' + type.toLowerCase());
			}

		};
	} else {
		var resource = $resource(SERVER_CONFIG.ADMIN_SERVER_URL + '/user', {}, {
			'query': {
				url: SERVER_CONFIG.ADMIN_SERVER_URL + '/user/query',
				method: 'POST',
				isArray: true
			},
			'update': {method: 'PUT'}
		});
		return resource;
	}
});
